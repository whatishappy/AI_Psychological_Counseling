import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { sequelize } from '../src/db/sequelize';
import { Admin } from '../src/models/index';

/**
 * 主函数，用于创建管理员账户
 * 该函数会读取环境变量中的管理员信息，如果不存在则使用默认值
 * 然后连接数据库，检查是否已存在同名管理员，如果不存在则创建新的管理员账户
 * 
 * @returns {Promise<void>} 无返回值的异步函数
 */
async function main() {
    // 从环境变量获取管理员信息，如果未设置则使用默认值
    const username = process.env.ADMIN_USERNAME || 'admin';
    const email = process.env.ADMIN_EMAIL || 'admin@example.com';
    const password = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
    const role = (process.env.ADMIN_ROLE as 'super_admin' | 'content_admin' | 'user_admin') || 'super_admin';

    // 连接数据库并验证连接
    await sequelize.authenticate();

    // 检查是否已存在同名管理员账户
    const exist = await Admin.findOne({ where: { username } });
    if (exist) {
        console.log(`[seed] Admin already exists: ${username}`);
        process.exit(0);
    }

    // 对密码进行哈希处理并创建新的管理员账户
    const password_hash = await bcrypt.hash(password, 10);
    const created = await Admin.create({ username, email, password_hash, role, is_active: true });
    console.log(`[seed] Admin created -> id=${created.getDataValue('admin_id')} username=${username} role=${role}`);
    process.exit(0);
}

main().catch((err) => {
    console.error('[seed] Failed to create admin:', err);
    process.exit(1);
});


