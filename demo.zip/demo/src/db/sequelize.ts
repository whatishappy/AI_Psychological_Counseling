import { Sequelize } from 'sequelize';

/**
 * 从环境变量中解构数据库连接配置信息
 * 默认值分别为：
 * - DB_HOST: 'localhost'
 * - DB_PORT: '3306'
 * - DB_USER: 'root'
 * - DB_PASSWORD: ''
 * - DB_NAME: 'ai_psychology_platform'
 */
const {
    DB_HOST = 'localhost',
    DB_PORT = '3306',
    DB_USER = 'root',
    DB_PASSWORD = '',
    DB_NAME = 'ai_psychology_platform'
} = process.env;

/**
 * 创建并导出Sequelize数据库连接实例
 * 用于与MySQL数据库建立连接并进行ORM操作
 * 配置了数据库连接参数、禁用日志输出、禁用时间戳字段等选项
 */
export const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASSWORD, {
    host: DB_HOST,
    port: Number(DB_PORT),
    dialect: 'mysql',
    logging: false,
    define: {
        timestamps: false
    }
});