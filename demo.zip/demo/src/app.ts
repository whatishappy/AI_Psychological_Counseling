/**
 * 导入环境变量配置、Express框架及相关中间件。
 * 初始化数据库连接，并注册各模块的路由。
 * 设置安全策略、CORS支持、JSON解析及静态资源服务。
 * 提供健康检查接口与全局错误处理机制。
 */

import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { json } from 'express';
import { sequelize } from './db/sequelize';
import authRouter from './routes/auth';
import consultationRouter from './routes/consultations';
import plansRouter from './routes/plans';
import measurementsRouter from './routes/measurements';
import assessmentsRouter from './routes/assessments';
import adminRouter from './routes/admin';
import path from 'path';

const app = express();

// 应用安全相关的HTTP头设置，增强应用安全性
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        ...helmet.contentSecurityPolicy.getDefaultDirectives(),
        "script-src": ["'self'", "'unsafe-inline'"],
        "script-src-attr": ["'self'", "'unsafe-inline'"],
      },
    },
  })
);

// 启用跨域资源共享（CORS）支持
app.use(cors());

// 解析请求体中的JSON数据，限制大小为1MB
app.use(json({ limit: '1mb' }));

// 提供项目根目录下的静态文件访问支持
app.use(express.static(path.join(__dirname, '..')));

/**
 * 健康检查端点，用于监控服务是否正常运行。
 * @param _req - 请求对象（未使用）
 * @param res - 响应对象，返回当前时间戳和状态信息
 */
app.get('/health', (_req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
});

// 注册各个业务模块的API路由
app.use('/api/auth', authRouter);
app.use('/api/consultations', consultationRouter);
app.use('/api/plans', plansRouter);
app.use('/api/measurements', measurementsRouter);
app.use('/api/assessments', assessmentsRouter);
app.use('/api/admin', adminRouter);

/**
 * 全局错误处理中间件，捕获未被处理的异常并统一响应格式。
 * 在开发环境下会暴露详细的错误消息，在生产环境中隐藏敏感信息。
 * @param err - 错误对象
 * @param _req - 请求对象（未使用）
 * @param res - 响应对象
 * @param _next - 下一个中间件函数（未使用）
 */
app.use((err: any, _req: any, res: any, _next: any) => {
    console.error('Unhandled error:', err);
    res.status(500).json({ 
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
    });
});

/**
 * 处理所有未匹配到路由的情况，返回404状态码。
 * 此中间件必须放置于所有路由定义之后以确保正确执行顺序。
 * @param _req - 请求对象（未使用）
 * @param res - 响应对象
 */
app.use((_req, res) => {
    res.status(404).json({ error: 'Not found' });
});

const PORT = process.env.PORT || 3000;

/**
 * 启动应用程序主逻辑，包括数据库连接测试、模型同步以及HTTP服务器监听。
 * 包含优雅关闭流程，当接收到中断信号时释放数据库连接并终止进程。
 */
async function start() {
    try {
        // 测试数据库连接是否成功建立
        await sequelize.authenticate();
        console.log('Database connection has been established successfully.');
        
        // 将定义的数据模型同步至数据库结构
        await sequelize.sync();
        console.log('Database models synchronized.');
        
        // 开始监听指定端口上的HTTP请求
        const server = app.listen(PORT, () => {
            console.log(`Server listening on port ${PORT}`);
        });
        
        /**
         * 监听系统中断信号(SIGINT)，实现优雅停机：
         * 关闭数据库连接 -> 终止HTTP服务器 -> 退出Node.js进程
         */
        process.on('SIGINT', async () => {
            console.log('Shutting down gracefully...');
            await sequelize.close();
            server.close(() => {
                console.log('Process terminated.');
                process.exit(0);
            });
        });
    } catch (err) {
        console.error('Failed to start server', err);
        process.exit(1);
    }
}

// 当前脚本作为入口文件被执行时才调用start函数启动服务
if (require.main === module) {
    start();
}

export default app;