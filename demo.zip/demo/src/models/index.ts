import { DataTypes, Model } from 'sequelize';
import { sequelize } from '../db/sequelize';

/**
 * 用户模型属性接口
 * 定义了用户表中各个字段的类型和可选性
 */
export interface UserAttributes {
    user_id: number;
    username: string;
    password_hash: string;
    email?: string | null;
    phone?: string | null;
    nickname?: string | null;
    avatar_url?: string | null;
    hobbies?: string | null; // JSON
    user_type?: 'guest' | 'registered';
    age?: number | null;
    gender?: 'male' | 'female' | 'other' | null;
    created_at?: Date;
    updated_at?: Date;
    last_login?: Date | null;
    is_active?: boolean;
}

/**
 * 用户创建属性类型
 * 排除自动生成的字段，用于创建新用户时的类型定义
 */
type UserCreationAttributes = Omit<UserAttributes, 'user_id' | 'created_at' | 'updated_at'>;

/**
 * 用户模型类
 * 继承自Sequelize的Model类，实现了UserAttributes接口
 * 用于操作用户表的数据
 */
class User extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
    declare user_id: number;
    declare username: string;
    declare password_hash: string;
    declare email: string | null;
    declare phone: string | null;
    declare nickname: string | null;
    declare avatar_url: string | null;
    declare hobbies: string | null;
    declare user_type: 'guest' | 'registered';
    declare age: number | null;
    declare gender: 'male' | 'female' | 'other' | null;
    declare created_at: Date;
    declare updated_at: Date;
    declare last_login: Date | null;
    declare is_active: boolean;
}

User.init(
    {
        user_id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        username: {
            type: DataTypes.STRING(50),
            allowNull: false,
            unique: true
        },
        password_hash: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(100),
            allowNull: true,
            unique: true
        },
        phone: {
            type: DataTypes.STRING(20),
            allowNull: true
        },
        hobbies: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        user_type: {
            type: DataTypes.ENUM('registered', 'guest'),
            allowNull: false,
            defaultValue: 'registered'
        },
        age: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        gender: {
            type: DataTypes.ENUM('male', 'female', 'other'),
            allowNull: true
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW
        },
        last_login: {
            type: DataTypes.DATE,
            allowNull: true
        },
        is_active: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        }
    },
    {
        sequelize,
        tableName: 'users',
        timestamps: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    }
);

/**
 * 咨询会话模型属性接口
 * 定义了咨询会话表中各个字段的类型和可选性
 */
interface ConsultationSessionAttributes {
    session_id: number;
    user_id?: number | null;
    session_title?: string | null;
    user_query: string;
    ai_response: string;
    consultation_type?: 'psychological' | 'sports_advice' | 'comprehensive';
    mood_rating?: number | null;
    session_duration?: number | null;
    assessment_result?: string | null;
    created_at?: Date;
}

/**
 * 咨询会话创建属性类型
 * 排除自动生成的字段，用于创建新咨询会话时的类型定义
 */
type ConsultationSessionCreationAttributes = Omit<ConsultationSessionAttributes, 'session_id'>;

/**
 * 咨询会话模型类
 * 继承自Sequelize的Model类，实现了ConsultationSessionAttributes接口
 * 用于操作咨询会话表的数据
 */
class ConsultationSession extends Model<ConsultationSessionAttributes, ConsultationSessionCreationAttributes>
    implements ConsultationSessionAttributes {
    public session_id!: number;
    public user_id!: number | null;
    public session_title!: string | null;
    public user_query!: string;
    public ai_response!: string;
    public consultation_type!: 'psychological' | 'sports_advice' | 'comprehensive';
    public mood_rating!: number | null;
    public session_duration!: number | null;
    public assessment_result!: string | null;
    public created_at!: Date;
}

ConsultationSession.init(
    {
        session_id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
                model: User,
                key: 'user_id'
            }
        },
        session_title: { type: DataTypes.STRING(200), allowNull: true },
        user_query: { type: DataTypes.TEXT, allowNull: false },
        ai_response: { type: DataTypes.TEXT, allowNull: false },
        consultation_type: { 
            type: DataTypes.ENUM('psychological', 'sports_advice', 'comprehensive'), 
            defaultValue: 'psychological' 
        },
        mood_rating: { type: DataTypes.INTEGER, allowNull: true },
        session_duration: { type: DataTypes.INTEGER, allowNull: true },
        assessment_result: { type: DataTypes.TEXT, allowNull: true },
        created_at: { type: DataTypes.DATE, allowNull: true, defaultValue: DataTypes.NOW }
    },
    { 
        sequelize, 
        tableName: 'consultation_sessions',
        timestamps: true,
        createdAt: 'created_at',
        updatedAt: false
    }
);

/**
 * 咨询消息模型属性接口
 * 定义了咨询消息表中各个字段的类型和可选性
 */
interface ConsultationMessageAttributes {
    message_id: number;
    session_id: number;
    message_type: 'user' | 'ai';
    content: string;
    mood_rating?: number | null;
    created_at?: Date;
}

/**
 * 咨询消息创建属性类型
 * 排除自动生成的字段，用于创建新咨询消息时的类型定义
 */
type ConsultationMessageCreationAttributes = Omit<ConsultationMessageAttributes, 'message_id'>;

/**
 * 咨询消息模型类
 * 继承自Sequelize的Model类，实现了ConsultationMessageAttributes接口
 * 用于操作咨询消息表的数据
 */
class ConsultationMessage extends Model<ConsultationMessageAttributes, ConsultationMessageCreationAttributes>
    implements ConsultationMessageAttributes {
    public message_id!: number;
    public session_id!: number;
    public message_type!: 'user' | 'ai';
    public content!: string;
    public mood_rating!: number | null;
    public created_at!: Date;
}

ConsultationMessage.init(
    {
        message_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        session_id: { 
            type: DataTypes.INTEGER, 
            allowNull: false,
            references: {
                model: ConsultationSession,
                key: 'session_id'
            }
        },
        message_type: { type: DataTypes.ENUM('user', 'ai'), allowNull: false },
        content: { type: DataTypes.TEXT, allowNull: false },
        mood_rating: { type: DataTypes.INTEGER, allowNull: true },
        created_at: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
    },
    {
        sequelize,
        tableName: 'consultation_messages',
        timestamps: true,
        createdAt: 'created_at',
        updatedAt: false
    }
);

/**
 * 运动计划模型类
 * 继承自Sequelize的Model类
 * 用于操作运动计划表的数据
 */
class ExercisePlan extends Model {
    public plan_id!: number;
    public user_id!: number;
    public session_id!: number;
    public plan_name!: string;
    public plan_description!: string | null;
    public plan_type!: string | null;
    public duration_minutes!: number | null;
    public intensity_level!: string | null;
    public scheduled_date!: Date | null;
    public completed!: boolean;
    public created_at!: Date;
}

ExercisePlan.init(
    {
        plan_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { 
            type: DataTypes.INTEGER, 
            allowNull: false,
            references: {
                model: User,
                key: 'user_id'
            }
        },
        session_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
                model: ConsultationSession,
                key: 'session_id'
            }
        },
        plan_name: { type: DataTypes.STRING(100), allowNull: false },
        plan_description: { type: DataTypes.TEXT, allowNull: true },
        plan_type: { type: DataTypes.STRING(50), allowNull: true },
        duration_minutes: { type: DataTypes.INTEGER, allowNull: true },
        intensity_level: { type: DataTypes.STRING(20), allowNull: true },
        scheduled_date: { type: DataTypes.DATEONLY, allowNull: true },
        completed: { type: DataTypes.BOOLEAN, defaultValue: false },
        created_at: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
    },
    {
        sequelize,
        tableName: 'exercise_plans',
        timestamps: true,
        createdAt: 'created_at',
        updatedAt: false
    }
);

/**
 * 身体测量模型类
 * 继承自Sequelize的Model类
 * 用于操作身体测量表的数据
 */
class BodyMeasurement extends Model {
    public measurement_id!: number;
    public user_id!: number;
    public weight!: number | null;
    public height!: number | null;
    public waist_circumference!: number | null;
    public chest_circumference!: number | null;
    public hip_circumference!: number | null;
    public bmi!: number | null;
    public body_fat_percentage!: number | null;
    public muscle_mass!: number | null;
    public measurement_date!: Date;
    public notes!: string | null;
    public created_at!: Date | null;
}

BodyMeasurement.init(
    {
        measurement_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { type: DataTypes.INTEGER, allowNull: false },
        weight: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        height: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        waist_circumference: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        chest_circumference: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        hip_circumference: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        bmi: { type: DataTypes.DECIMAL(4, 2), allowNull: true },
        body_fat_percentage: { type: DataTypes.DECIMAL(4, 2), allowNull: true },
        muscle_mass: { type: DataTypes.DECIMAL(5, 2), allowNull: true },
        measurement_date: { type: DataTypes.DATEONLY, allowNull: false },
        notes: { type: DataTypes.TEXT, allowNull: true },
        created_at: { type: DataTypes.DATE, allowNull: true }
    },
    { sequelize, tableName: 'body_measurements' }
);

/**
 * 心理评估模型类
 * 继承自Sequelize的Model类
 * 用于操作心理评估表的数据
 */
class PsychologicalAssessment extends Model {
    public assessment_id!: number;
    public user_id!: number;
    public assessment_date!: Date;
    public overall_score!: number | null;
    public stress_level!: number | null;
    public anxiety_level!: number | null;
    public depression_level!: number | null;
    public sleep_quality!: number | null;
    public social_support!: number | null;
    public assessment_details!: any | null;
    public recommendations!: string | null;
    public created_at!: Date | null;
}

PsychologicalAssessment.init(
    {
        assessment_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { type: DataTypes.INTEGER, allowNull: false },
        assessment_date: { type: DataTypes.DATEONLY, allowNull: false },
        overall_score: { type: DataTypes.INTEGER, allowNull: true },
        stress_level: { type: DataTypes.INTEGER, allowNull: true },
        anxiety_level: { type: DataTypes.INTEGER, allowNull: true },
        depression_level: { type: DataTypes.INTEGER, allowNull: true },
        sleep_quality: { type: DataTypes.INTEGER, allowNull: true },
        social_support: { type: DataTypes.INTEGER, allowNull: true },
        assessment_details: { type: DataTypes.JSON, allowNull: true },
        recommendations: { type: DataTypes.TEXT, allowNull: true },
        created_at: { type: DataTypes.DATE, allowNull: true }
    },
    { sequelize, tableName: 'psychological_assessments' }
);

/**
 * 身体评估模型类
 * 继承自Sequelize的Model类
 * 用于操作身体评估表的数据
 */
class PhysicalAssessment extends Model {
    public assessment_id!: number;
    public user_id!: number;
    public assessment_date!: Date;
    public overall_score!: number | null;
    public cardiovascular_level!: number | null;
    public strength_level!: number | null;
    public flexibility_level!: number | null;
    public endurance_level!: number | null;
    public assessment_details!: any | null;
    public recommendations!: string | null;
    public created_at!: Date | null;
}

PhysicalAssessment.init(
    {
        assessment_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { type: DataTypes.INTEGER, allowNull: false },
        assessment_date: { type: DataTypes.DATEONLY, allowNull: false },
        overall_score: { type: DataTypes.INTEGER, allowNull: true },
        cardiovascular_level: { type: DataTypes.INTEGER, allowNull: true },
        strength_level: { type: DataTypes.INTEGER, allowNull: true },
        flexibility_level: { type: DataTypes.INTEGER, allowNull: true },
        endurance_level: { type: DataTypes.INTEGER, allowNull: true },
        assessment_details: { type: DataTypes.JSON, allowNull: true },
        recommendations: { type: DataTypes.TEXT, allowNull: true },
        created_at: { type: DataTypes.DATE, allowNull: true }
    },
    { sequelize, tableName: 'physical_assessments' }
);

/**
 * 管理员模型属性接口
 * 定义了管理员表中各个字段的类型和可选性
 */
interface AdminAttributes {
    admin_id: number;
    username: string;
    password_hash: string;
    email: string;
    full_name?: string | null;
    role: 'super_admin' | 'content_admin' | 'user_admin';
    is_active: boolean;
    created_at?: Date | null;
    last_login?: Date | null;
}

/**
 * 管理员创建属性类型
 * 排除自动生成的字段，用于创建新管理员时的类型定义
 */
type AdminCreationAttributes = Omit<AdminAttributes, 'admin_id'>;

/**
 * 管理员模型类
 * 继承自Sequelize的Model类，实现了AdminAttributes接口
 * 用于操作管理员表的数据
 */
class Admin extends Model<AdminAttributes, AdminCreationAttributes> implements AdminAttributes {
    public admin_id!: number;
    public username!: string;
    public password_hash!: string;
    public email!: string;
    public full_name!: string | null;
    public role!: 'super_admin' | 'content_admin' | 'user_admin';
    public is_active!: boolean;
    public created_at!: Date | null;
    public last_login!: Date | null;
}

Admin.init(
    {
        admin_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        username: { type: DataTypes.STRING(50), allowNull: false, unique: true },
        password_hash: { type: DataTypes.STRING(255), allowNull: false },
        email: { type: DataTypes.STRING(100), allowNull: false, unique: true },
        full_name: { type: DataTypes.STRING(100), allowNull: true },
        role: { type: DataTypes.ENUM('super_admin', 'content_admin', 'user_admin'), defaultValue: 'user_admin' },
        is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
        created_at: { type: DataTypes.DATE, allowNull: true },
        last_login: { type: DataTypes.DATE, allowNull: true }
    },
    { 
        sequelize, 
        tableName: 'admins',
        timestamps: false
    }
);

/**
 * 用户登录日志模型类
 * 继承自Sequelize的Model类
 * 用于操作用户登录日志表的数据
 */
class UserLoginLog extends Model {
    public log_id!: number;
    public user_id!: number | null;
    public login_type!: 'guest' | 'registered';
    public ip_address!: string | null;
    public user_agent!: string | null;
    public login_time!: Date | null;
    public session_duration!: number | null;
}

UserLoginLog.init(
    {
        log_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { type: DataTypes.INTEGER, allowNull: true },
        login_type: { type: DataTypes.ENUM('guest', 'registered'), allowNull: false },
        ip_address: { type: DataTypes.STRING(45), allowNull: true },
        user_agent: { type: DataTypes.TEXT, allowNull: true },
        login_time: { type: DataTypes.DATE, allowNull: true },
        session_duration: { type: DataTypes.INTEGER, allowNull: true }
    },
    { sequelize, tableName: 'user_login_logs' }
);

// 建立模型关联
User.hasMany(ConsultationSession, { foreignKey: 'user_id' });
ConsultationSession.belongsTo(User, { foreignKey: 'user_id' });
ConsultationSession.hasMany(ConsultationMessage, { foreignKey: 'session_id' });
ConsultationMessage.belongsTo(ConsultationSession, { foreignKey: 'session_id' });

User.hasMany(ExercisePlan, { foreignKey: 'user_id' });
ExercisePlan.belongsTo(User, { foreignKey: 'user_id' });

ExercisePlan.belongsTo(ConsultationSession, { foreignKey: 'session_id' });

User.hasMany(BodyMeasurement, { foreignKey: 'user_id' });
BodyMeasurement.belongsTo(User, { foreignKey: 'user_id' });

User.hasMany(PsychologicalAssessment, { foreignKey: 'user_id' });
PsychologicalAssessment.belongsTo(User, { foreignKey: 'user_id' });

User.hasMany(PhysicalAssessment, { foreignKey: 'user_id' });
PhysicalAssessment.belongsTo(User, { foreignKey: 'user_id' });

User.hasMany(UserLoginLog, { foreignKey: 'user_id' });
UserLoginLog.belongsTo(User, { foreignKey: 'user_id' });

/**
 * 导出所有模型类
 * 供其他模块使用
 */
export { 
    User, 
    ConsultationSession, 
    ConsultationMessage,
    ExercisePlan, 
    BodyMeasurement, 
    PsychologicalAssessment, 
    PhysicalAssessment, 
    Admin, 
    UserLoginLog 
};

/**
 * 单独导出类型定义
 * 供其他模块使用
 */
export type { 
    ConsultationSessionAttributes,
    ConsultationMessageAttributes
};