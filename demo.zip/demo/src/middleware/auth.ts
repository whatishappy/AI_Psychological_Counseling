import jwt, { Secret, SignOptions } from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

export interface AuthPayload {
    userId: number | null; // null for guest
    userType: 'guest' | 'registered' | 'admin';
}

declare module 'express-serve-static-core' {
    interface Request {
        auth?: AuthPayload;
    }
}

const JWT_SECRET: Secret = process.env.JWT_SECRET || 'dev-secret';

/**
 * 签名生成JWT令牌
 * @param payload - 认证载荷数据，包含用户认证信息
 * @param expiresIn - 令牌过期时间，默认为7天，遵循jsonwebtoken库的时间格式规范
 * @returns 返回签名后的JWT令牌字符串
 */
export function signToken(payload: AuthPayload, expiresIn: SignOptions['expiresIn'] = '7d' as unknown as SignOptions['expiresIn']) {
    // 构造JWT签名选项配置
    const options: SignOptions = { expiresIn } as SignOptions;
    // 使用JWT库生成签名令牌
    return jwt.sign(payload as object, JWT_SECRET, options);
}

/**
 * 身份验证中间件函数，用于验证请求中的JWT令牌
 * @param req - Express请求对象，包含客户端发送的请求信息
 * @param res - Express响应对象，用于向客户端发送响应
 * @param next - Express下一个中间件函数，调用后继续执行后续中间件
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
    const header = req.headers.authorization;
    // 检查请求头中是否包含授权信息
    if (!header) return res.status(401).json({ error: 'Unauthorized' });
    const token = header.replace('Bearer ', '');
    try {
        // 验证JWT令牌并解码用户信息
        const decoded = jwt.verify(token, JWT_SECRET) as AuthPayload;
        req.auth = decoded;
        next();
    } catch {
        // 令牌验证失败时返回401错误
        return res.status(401).json({ error: 'Invalid token' });
    }
}

/**
 * 可选身份验证中间件函数
 * 该函数用于解析请求头中的JWT令牌，如果存在有效的令牌则将解码后的用户信息附加到请求对象上
 * @param req - Express请求对象，用于获取授权头信息
 * @param _res - Express响应对象（未使用）
 * @param next - Express下一个中间件函数，调用后继续执行后续处理
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
    const header = req.headers.authorization;
    if (header) {
        const token = header.replace('Bearer ', '');
        try {
            const decoded = jwt.verify(token, JWT_SECRET) as AuthPayload;
            req.auth = decoded;
        } catch {
            // 忽略令牌验证失败的情况，保持可选认证的语义
        }
    }
    next();
}

/**
 * 中间件函数，用于验证用户是否为已注册用户或管理员
 * @param req - Express请求对象，应包含认证信息
 * @param res - Express响应对象，用于返回错误信息
 * @param next - Express下一个中间件函数，验证通过时调用
 */
export function requireRegistered(req: Request, res: Response, next: NextFunction) {
    // 检查用户是否已认证
    if (!req.auth) return res.status(401).json({ error: 'Unauthorized' });
    
    // 验证用户类型是否为已注册用户或管理员
    if (req.auth.userType !== 'registered' && req.auth.userType !== 'admin') {
        return res.status(403).json({ error: 'Registered users only' });
    }
    
    // 验证通过，继续执行下一个中间件
    next();
}

/**
 * 中间件函数，用于验证当前用户是否为管理员
 * @param req - Express请求对象，应包含认证信息
 * @param res - Express响应对象，用于返回错误信息
 * @param next - Express下一个中间件函数，验证通过时调用
 */
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
    // 验证用户权限，非管理员用户将被拒绝访问
    if (!req.auth || req.auth.userType !== 'admin') return res.status(403).json({ error: 'Admin only' });
    next();
}


