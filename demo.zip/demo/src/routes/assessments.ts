import { Router } from 'express';
import { requireRegistered } from '../middleware/auth';
import { PsychologicalAssessment, PhysicalAssessment } from '../models/index';
import { assessWeeklyPsych, assessWeeklyPhysical } from '../services/ai';

const router = Router();

/**
 * 获取当前用户的心理评估记录列表
 * 
 * @param req - Express请求对象，需包含认证信息
 * @param res - Express响应对象，返回心理评估记录数组
 */
router.get('/psych', requireRegistered, async (req, res) => {
    // 查询用户所有心理评估记录并按日期倒序排列
    const items = await PsychologicalAssessment.findAll({ 
        where: { user_id: req.auth!.userId! }, 
        order: [['assessment_date', 'DESC']] 
    });
    res.json(items);
});

/**
 * 创建新的心理评估记录
 * 
 * @param req - Express请求对象，包含用户ID和心理评估数据
 * @param res - Express响应对象，返回创建的心理评估记录
 */
router.post('/psych', requireRegistered, async (req, res) => {
    const user_id = req.auth!.userId!;
    const { assessment_date, stress_level, anxiety_level, sleep_quality, social_support } = req.body;
    
    // 使用AI服务评估心理状态并生成总体评分和建议
    const { overall, recommendations } = assessWeeklyPsych({ 
        stress: stress_level, 
        anxiety: anxiety_level, 
        sleep: sleep_quality, 
        support: social_support 
    });
    
    // 创建新的心理评估记录
    const created = await PsychologicalAssessment.create({
        user_id,
        assessment_date,
        overall_score: overall,
        stress_level,
        anxiety_level,
        sleep_quality,
        social_support,
        assessment_details: req.body,
        recommendations
    });
    res.json(created);
});

/**
 * 获取当前用户的体能评估记录列表
 * 
 * @param req - Express请求对象，需包含认证信息
 * @param res - Express响应对象，返回体能评估记录数组
 */
router.get('/physical', requireRegistered, async (req, res) => {
    // 查询用户所有体能评估记录并按日期倒序排列
    const items = await PhysicalAssessment.findAll({ 
        where: { user_id: req.auth!.userId! }, 
        order: [['assessment_date', 'DESC']] 
    });
    res.json(items);
});

/**
 * 创建新的体能评估记录
 * 
 * @param req - Express请求对象，包含用户ID和体能评估数据
 * @param res - Express响应对象，返回创建的体能评估记录
 */
router.post('/physical', requireRegistered, async (req, res) => {
    const user_id = req.auth!.userId!;
    const { assessment_date, cardiovascular_level, strength_level, flexibility_level, endurance_level } = req.body;
    
    // 使用AI服务评估体能状态并生成总体评分和建议
    const { overall, recommendations } = assessWeeklyPhysical({ 
        cardio: cardiovascular_level, 
        strength: strength_level, 
        flexibility: flexibility_level, 
        endurance: endurance_level 
    });
    
    // 创建新的体能评估记录
    const created = await PhysicalAssessment.create({
        user_id,
        assessment_date,
        overall_score: overall,
        cardiovascular_level,
        strength_level,
        flexibility_level,
        endurance_level,
        assessment_details: req.body,
        recommendations
    });
    res.json(created);
});

export default router;

