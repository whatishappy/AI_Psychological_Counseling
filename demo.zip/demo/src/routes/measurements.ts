import { Router } from 'express';
import { requireRegistered } from '../middleware/auth';
import { BodyMeasurement } from '../models/index';

const router = Router();

/**
 * 获取当前用户的所有身体测量数据
 * 按测量日期升序排列
 * @param req - Express请求对象，包含认证信息
 * @param res - Express响应对象，用于返回数据
 */
router.get('/', requireRegistered, async (req, res) => {
    // 查询当前用户的所有身体测量记录，并按日期升序排序
    const data = await BodyMeasurement.findAll({ where: { user_id: req.auth!.userId! }, order: [['measurement_date', 'ASC']] });
    res.json(data);
});

/**
 * 创建新的身体测量记录
 * @param req - Express请求对象，包含认证信息和请求体数据
 * @param res - Express响应对象，用于返回创建的结果
 */
router.post('/', requireRegistered, async (req, res) => {
    // 将用户ID添加到请求体数据中，确保数据归属于当前用户
    const user_id = req.auth!.userId!;
    const payload = { ...req.body, user_id };
    const created = await BodyMeasurement.create(payload);
    res.json(created);
});

/**
 * 更新指定的身体测量记录
 * @param req - Express请求对象，包含认证信息、路径参数和请求体数据
 * @param res - Express响应对象，用于返回更新后的结果或错误信息
 */
router.put('/:id', requireRegistered, async (req, res) => {
    // 验证记录是否存在且属于当前用户
    const item = await BodyMeasurement.findOne({ where: { measurement_id: Number(req.params.id), user_id: req.auth!.userId! } });
    if (!item) return res.status(404).json({ error: 'Not found' });
    
    // 更新记录并返回结果
    await item.update(req.body);
    res.json(item);
});

/**
 * 删除指定的身体测量记录
 * @param req - Express请求对象，包含认证信息和路径参数
 * @param res - Express响应对象，用于返回删除结果或错误信息
 */
router.delete('/:id', requireRegistered, async (req, res) => {
    // 验证记录是否存在且属于当前用户
    const item = await BodyMeasurement.findOne({ where: { measurement_id: Number(req.params.id), user_id: req.auth!.userId! } });
    if (!item) return res.status(404).json({ error: 'Not found' });
    
    // 删除记录并返回成功状态
    await item.destroy();
    res.json({ ok: true });
});

export default router;


