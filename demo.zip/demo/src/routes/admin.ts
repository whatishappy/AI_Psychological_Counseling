import { Router } from 'express';
import { requireAdmin, requireRegistered } from '../middleware/auth';
import { User, UserLoginLog } from '../models/index';

const router = Router();

/**
 * 获取用户登录日志列表
 * 
 * @param _req - Express请求对象，未使用
 * @param res - Express响应对象，用于返回登录日志数据
 * 
 * @description 获取最近200条用户登录日志，按登录时间倒序排列
 * 注意：当前为演示目的，使用requireRegistered中间件，后续可能调整为requireAdmin权限
 */
router.get('/logins', requireRegistered, async (_req, res) => {
    const items = await UserLoginLog.findAll({ order: [['login_time', 'DESC']], limit: 200 });
    res.json(items);
});

/**
 * 获取用户列表
 * 
 * @param _req - Express请求对象，未使用
 * @param res - Express响应对象，用于返回用户数据
 * 
 * @description 获取所有用户的基本信息，包括用户ID、用户名、昵称、用户类型、最后登录时间和创建时间
 */
router.get('/users', requireRegistered, async (_req, res) => {
    const items = await User.findAll({ attributes: ['user_id', 'username', 'nickname', 'user_type', 'last_login', 'created_at'] });
    res.json(items);
});

export default router;