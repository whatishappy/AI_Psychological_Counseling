import { Router } from 'express';
import { body } from 'express-validator';
import bcrypt from 'bcryptjs';
import { User, UserLoginLog } from '../models/index';
import { signToken } from '../middleware/auth';

const router = Router();

/**
 * 用户注册接口
 * 
 * @param req - Express请求对象，包含用户提交的注册信息（username, password, email, phone, nickname）
 * @param res - Express响应对象，用于返回注册结果或错误信息
 * 
 * @description
 * 该接口处理用户注册请求，包括：
 * 1. 验证用户名和密码长度
 * 2. 检查用户名和邮箱是否已存在
 * 3. 对密码进行哈希加密
 * 4. 创建新用户记录
 * 5. 生成JWT令牌
 * 6. 记录登录日志
 * 
 * @returns 返回包含JWT令牌和用户基本信息的JSON响应
 */
router.post(
    '/register',
    body('username').isLength({ min: 3 }),
    body('password').isLength({ min: 6 }),
    async (req, res) => {
        try {
            const { username, password, email, phone, nickname } = req.body;
            console.log('Registration attempt:', { username, email }); // 添加日志
            
            const existing = await User.findOne({ where: { username } });
            if (existing) {
                console.log('Username already exists:', username); // 添加日志
                return res.status(409).json({ error: 'Username exists' });
            }
            
            // 检查邮箱是否已存在
            if (email) {
                const existingEmail = await User.findOne({ where: { email } });
                if (existingEmail) {
                    console.log('Email already registered:', email); // 添加日志
                    return res.status(409).json({ error: 'Email already registered' });
                }
            }
            
            const password_hash = await bcrypt.hash(password, 10);
            console.log('Creating user with data:', { username, email, phone, nickname }); // 添加日志
            
            const user = await User.create({ username, password_hash, email, phone, nickname, user_type: 'registered' });
            console.log('User created successfully:', user.getDataValue('user_id')); // 添加日志
            
            const token = signToken({ userId: user.getDataValue('user_id'), userType: 'registered' });
            await UserLoginLog.create({ user_id: user.getDataValue('user_id'), login_type: 'registered', user_agent: req.headers['user-agent'] || '' });
            res.json({ token, user: { user_id: user.getDataValue('user_id'), username, nickname: user.getDataValue('nickname') } });
        } catch (error) {
            console.error('Registration error:', error);
            res.status(500).json({ error: 'Registration failed' });
        }
    }
);

/**
 * 用户登录接口
 * 
 * @param req - Express请求对象，包含用户提交的登录凭证（username, password）
 * @param res - Express响应对象，用于返回登录结果或错误信息
 * 
 * @description
 * 该接口处理用户登录请求，包括：
 * 1. 验证用户是否存在
 * 2. 验证密码正确性
 * 3. 生成JWT令牌
 * 4. 更新用户最后登录时间
 * 5. 记录登录日志
 * 
 * @returns 返回包含JWT令牌的JSON响应
 */
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log('Login attempt:', { username }); // 添加日志
        
        const user = await User.findOne({ where: { username } });
        if (!user) {
            console.log('User not found:', username); // 添加日志
            return res.status(401).json({ error: '用户名或密码错误' });
        }
        
        console.log('User found, checking password...'); // 添加日志
        const ok = await bcrypt.compare(password, user.getDataValue('password_hash'));
        if (!ok) {
            console.log('Invalid password for user:', username); // 添加日志
            return res.status(401).json({ error: '用户名或密码错误' });
        }
        
        const token = signToken({ userId: user.getDataValue('user_id'), userType: 'registered' });
        await user.update({ last_login: new Date() });
        await UserLoginLog.create({ user_id: user.getDataValue('user_id'), login_type: 'registered', user_agent: req.headers['user-agent'] || '' });
        res.json({ token });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: '登录失败' });
    }
});

/**
 * 游客登录接口
 * 
 * @param req - Express请求对象
 * @param res - Express响应对象，用于返回游客令牌或错误信息
 * 
 * @description
 * 该接口为匿名用户提供临时访问权限，创建一个有效期为1天的游客JWT令牌，
 * 并记录相应的登录日志。不需要创建用户记录。
 * 
 * @returns 返回包含游客JWT令牌的JSON响应
 */
router.post('/guest', async (req, res) => {
    // anonymous session for quick consultation; no user row required
    try {
        const token = signToken({ userId: null, userType: 'guest' }, '1d');
        await UserLoginLog.create({ user_id: null, login_type: 'guest', user_agent: req.headers['user-agent'] || '' });
        res.json({ token });
    } catch (error) {
        console.error('Guest login error:', error);
        res.status(500).json({ error: 'Guest login failed' });
    }
});

export default router;