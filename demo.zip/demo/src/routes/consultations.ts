import { Router, Request, Response } from 'express';
import { requireAuth } from '../middleware/auth';
import { ConsultationSession, ConsultationMessage } from '../models';
import { generatePsychologicalAdvice } from '../services/ai';

const router = Router();

/**
 * 请求体接口定义：用于创建咨询消息的请求数据结构
 */
interface ConsultationRequestBody {
    /**
     * 用户输入的问题或描述
     */
    user_query: string;

    /**
     * 咨询类型（可选），默认为 'psychological'
     */
    consultation_type?: 'psychological' | 'sports_advice' | 'comprehensive';

    /**
     * 情绪评分（可选）
     */
    mood_rating?: number;

    /**
     * 基础用户资料（可选）
     */
    base_profile?: any;
}

/**
 * POST / - 创建一个新的心理咨询会话并生成AI建议
 *
 * @param req - Express 请求对象，包含认证信息和请求体数据
 * @param res - Express 响应对象，用于返回结果给客户端
 * 
 * 功能流程：
 * 1. 验证请求参数是否合法；
 * 2. 调用 AI 服务生成心理建议；
 * 3. 根据用户身份查找或创建会话记录；
 * 4. 更新会话中的最新提问与回答；
 * 5. 分别保存用户的提问和AI的回答到消息表中；
 * 6. 返回会话ID及AI响应内容。
 */
router.post('/', requireAuth, async (req: Request<{}, {}, ConsultationRequestBody>, res: Response) => {
    try {
        const { user_query, consultation_type, mood_rating, base_profile } = req.body;
        
        // 验证请求参数
        if (!user_query || typeof user_query !== 'string') {
            return res.status(400).json({ error: 'Invalid user query' });
        }
        
        // 生成AI响应
        const ai_response = await generatePsychologicalAdvice(user_query);
        
        // 处理用户ID（游客为null，注册用户为实际ID）
        const userId = req.auth?.userId || null;
        
        // 创建或获取会话
        const [session] = await ConsultationSession.findOrCreate({
            where: { 
                user_id: userId
            },
            defaults: { 
                user_id: userId, 
                consultation_type: consultation_type || 'psychological',
                user_query: user_query,
                ai_response: ai_response
            }
        });
        
        // 如果会话已存在，更新最新的用户查询和AI响应
        if (session.getDataValue('user_query') !== user_query || session.getDataValue('ai_response') !== ai_response) {
            await session.update({
                user_query: user_query,
                ai_response: ai_response
            });
        }
        
        // 创建用户消息记录
        await ConsultationMessage.create({
            session_id: session.getDataValue('session_id'),
            message_type: 'user',
            content: user_query
        });
        
        // 创建AI回复记录
        await ConsultationMessage.create({
            session_id: session.getDataValue('session_id'),
            message_type: 'ai',
            content: ai_response
        });
        
        res.json({
            session_id: session.getDataValue('session_id'),
            ai_response: ai_response
        });
    } catch (error) {
        console.error('Consultation error:', error);
        res.status(500).json({ error: 'Failed to process consultation' });
    }
});

export default router;