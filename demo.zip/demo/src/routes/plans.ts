import { Router } from 'express';
import { requireRegistered } from '../middleware/auth';
import { ExercisePlan } from '../models/index';

const router = Router();

/**
 * 获取当前用户的所有训练计划列表
 * 按创建时间倒序排列
 * 
 * @param req - HTTP请求对象，包含认证信息
 * @param res - HTTP响应对象，用于返回训练计划数据
 */
router.get('/', requireRegistered, async (req, res) => {
    // 查询当前用户的所有训练计划，按创建时间倒序排列
    const items = await ExercisePlan.findAll({ where: { user_id: req.auth!.userId! }, order: [['created_at', 'DESC']] });
    res.json(items);
});

/**
 * 创建新的训练计划
 * 
 * @param req - HTTP请求对象，包含认证信息和训练计划数据
 * @param res - HTTP响应对象，用于返回创建的训练计划
 */
router.post('/', requireRegistered, async (req, res) => {
    const user_id = req.auth!.userId!;
    // 创建新的训练计划，包含用户ID和请求体中的其他数据
    const plan = await ExercisePlan.create({ user_id, ...req.body });
    res.json(plan);
});

/**
 * 根据ID获取特定的训练计划
 * 
 * @param req - HTTP请求对象，包含认证信息和训练计划ID参数
 * @param res - HTTP响应对象，用于返回查询到的训练计划或错误信息
 */
router.get('/:id', requireRegistered, async (req, res) => {
    // 根据ID和用户ID查询特定的训练计划
    const plan = await ExercisePlan.findOne({ where: { plan_id: Number(req.params.id), user_id: req.auth!.userId! } });
    // 如果未找到对应训练计划，返回404错误
    if (!plan) return res.status(404).json({ error: 'Not found' });
    res.json(plan);
});

/**
 * 更新指定ID的训练计划
 * 
 * @param req - HTTP请求对象，包含认证信息、训练计划ID参数和更新数据
 * @param res - HTTP响应对象，用于返回更新后的训练计划或错误信息
 */
router.put('/:id', requireRegistered, async (req, res) => {
    // 根据ID和用户ID查询需要更新的训练计划
    const plan = await ExercisePlan.findOne({ where: { plan_id: Number(req.params.id), user_id: req.auth!.userId! } });
    // 如果未找到对应训练计划，返回404错误
    if (!plan) return res.status(404).json({ error: 'Not found' });
    // 更新训练计划数据
    await plan.update(req.body);
    res.json(plan);
});

/**
 * 删除指定ID的训练计划
 * 
 * @param req - HTTP请求对象，包含认证信息和训练计划ID参数
 * @param res - HTTP响应对象，用于返回删除结果或错误信息
 */
router.delete('/:id', requireRegistered, async (req, res) => {
    // 根据ID和用户ID查询需要删除的训练计划
    const plan = await ExercisePlan.findOne({ where: { plan_id: Number(req.params.id), user_id: req.auth!.userId! } });
    // 如果未找到对应训练计划，返回404错误
    if (!plan) return res.status(404).json({ error: 'Not found' });
    // 删除训练计划
    await plan.destroy();
    res.json({ ok: true });
});

export default router;
